# naskystore.zip

Full NASKY STORE package using ReplyKeyboardMarkup, not inline keyboards. `.env.example` includes `BACKUP_BOT_TOKEN`, `BACKUP_CHAT_ID`, database path, backup directory, interval, and max backups. The backup bot uploads a local SQLite backup with a read stream/multipart upload. [web:59][web:237][web:246]

Install:
```bash
cp .env.example .env
nano .env
npm install
node --check src/index.js
pm2 start ecosystem.config.cjs
pm2 save
```
