import { db } from '../database.js';

const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const DIGITS = '0123456789';

export function generateTagId() {
  let tag;
  const stmt = db.prepare('SELECT 1 FROM users WHERE tag_id = ?');
  do {
    const c1 = CHARS[Math.floor(Math.random() * 26)];
    const c2 = CHARS[Math.floor(Math.random() * 26)];
    const d1 = DIGITS[Math.floor(Math.random() * 10)];
    const d2 = DIGITS[Math.floor(Math.random() * 10)];
    const d3 = DIGITS[Math.floor(Math.random() * 10)];
    tag = `#${c1}${c2}${d1}${d2}${d3}`;
  } while (stmt.get(tag));
  return tag;
}

export function generateInvoiceCode() {
  const ts = Date.now().toString(36).toUpperCase();
  const rnd = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `INV-${ts}-${rnd}`;
}

export function generateUniqueCode() {
  return Math.floor(100 + Math.random() * 900);
}

export function getNextOrderRef() {
  const key = 'order_counter';
  const getStmt = db.prepare('SELECT value FROM settings WHERE key = ?');
  const updateStmt = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');

  const row = getStmt.get(key);
  const current = row ? parseInt(row.value, 10) : 0;
  const next = current + 1;
  if (next > 999999) {
    throw new Error('Order reference limit exceeded (#999999)');
  }
  updateStmt.run(key, next.toString());
  return '#' + next.toString().padStart(4, '0');
}

export function formatRupiah(num) {
  if (num === null || num === undefined) return 'Rp 0';
  return 'Rp ' + num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

export function escapeMarkdown(text) {
  if (!text) return '';
  return text.toString()
    .replace(/_/g, '\\_')
    .replace(/\*/g, '\\*')
    .replace(/\[/g, '\\[')
    .replace(/\]/g, '\\]')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)')
    .replace(/~/g, '\\~')
    .replace(/`/g, '\\`')
    .replace(/>/g, '\\>')
    .replace(/#/g, '\\#')
    .replace(/\+/g, '\\+')
    .replace(/-/g, '\\-')
    .replace(/=/g, '\\=')
    .replace(/\|/g, '\\|')
    .replace(/\{/g, '\\{')
    .replace(/\}/g, '\\}')
    .replace(/\./g, '\\.');
}

export function parseAmount(text) {
  const cleaned = text.replace(/[^\d]/g, '');
  const num = parseInt(cleaned, 10);
  return isNaN(num) ? null : num;
}

export function isAdmin(telegramId) {
  const adminIds = (process.env.ADMIN_IDS || '').split(',').map(id => id.trim()).filter(Boolean);
  return adminIds.includes(telegramId.toString());
}

export function getMainMenuKeyboard() {
  return {
    reply_markup: {
      keyboard: [
        ['🛒 Beli OTP', '👤 Profil'],
        ['💰 Saldo', '👥 Referral'],
        ['🏆 Leaderboard', '📋 Order Aktif'],
        ['📜 Riwayat']
      ],
      resize_keyboard: true
    }
  };
}

export function getSaldoMenuKeyboard() {
  return {
    reply_markup: {
      keyboard: [
        ['💳 Top Up', '📜 History Top Up'],
        ['⬅️ Kembali']
      ],
      resize_keyboard: true
    }
  };
}

export function getTopUpAmountKeyboard() {
  return {
    reply_markup: {
      keyboard: [
        ['Rp 10.000', 'Rp 25.000'],
        ['Rp 50.000', 'Rp 100.000'],
        ['✏️ Nominal Custom'],
        ['⬅️ Kembali']
      ],
      resize_keyboard: true
    }
  };
}

export function getAdminMenuKeyboard() {
  return {
    reply_markup: {
      keyboard: [
        ['📊 Statistik', '👥 Data User'],
        ['💳 Deposit Pending', '📦 Total Order'],
        ['📜 Riwayat', '📤 Upload QRIS'],
        ['🗄 Backup DB', '🔄 Refresh']
      ],
      resize_keyboard: true
    }
  };
}

export function getCancelKeyboard() {
  return {
    reply_markup: {
      keyboard: [['❌ Batal']],
      resize_keyboard: true
    }
  };
}

export function getBackKeyboard() {
  return {
    reply_markup: {
      keyboard: [['⬅️ Kembali']],
      resize_keyboard: true
    }
  };
}
