import QRCode from 'qrcode';

export async function generateQRISImage(qrisString) {
  if (!qrisString || typeof qrisString !== 'string') {
    throw new Error('QRIS string tidak valid atau belum dikonfigurasi');
  }
  try {
    const buffer = await QRCode.toBuffer(qrisString, {
      type: 'png',
      width: 400,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });
    return buffer;
  } catch (err) {
    throw new Error(`Gagal generate QRIS: ${err.message}`);
  }
}
