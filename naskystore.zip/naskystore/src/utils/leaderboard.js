import { db } from '../database.js';

export function refreshLeaderboard() {
  try {
    db.prepare('DELETE FROM leaderboard_cache').run();
    const users = db.prepare(`
      SELECT id, total_deposit 
      FROM users 
      ORDER BY total_deposit DESC 
      LIMIT 100
    `).all();

    const insert = db.prepare('INSERT INTO leaderboard_cache (user_id, rank, score) VALUES (?, ?, ?)');
    for (let i = 0; i < users.length; i++) {
      insert.run(users[i].id, i + 1, users[i].total_deposit);
    }
    console.log(`[Leaderboard] Refreshed: ${users.length} users`);
    return users.length;
  } catch (err) {
    console.error('[Leaderboard] Refresh error:', err);
    return 0;
  }
}

export function getLeaderboard() {
  try {
    return db.prepare(`
      SELECT l.rank, l.score, u.tag_id, u.username, u.full_name
      FROM leaderboard_cache l
      JOIN users u ON l.user_id = u.id
      ORDER BY l.rank ASC
      LIMIT 20
    `).all();
  } catch (err) {
    console.error('[Leaderboard] Get error:', err);
    return [];
  }
}
