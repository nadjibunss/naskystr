import express from 'express';
import { getInvoiceByCode, addNotification } from './database.js';

export function startWatcher(bot, db) {
  const app = express();
  app.use(express.json());

  const PORT = process.env.PORT || 3000;
  const WATCHER_SECRET = process.env.WATCHER_SECRET;

  app.post('/webhook/payment', async (req, res) => {
    try {
      // 1. Validate secret
      const secret = req.headers['x-watcher-secret'] || req.headers['watcher-secret'] || req.body.secret;
      if (!WATCHER_SECRET || secret !== WATCHER_SECRET) {
        console.warn('[Watcher] Invalid secret attempt');
        return res.status(401).json({ error: 'Unauthorized' });
      }

      // 2. Parse body
      const { amount, reference } = req.body;
      if (!amount || typeof amount !== 'number') {
        return res.status(400).json({ error: 'Missing or invalid amount' });
      }

      // 3. Find matching invoice
      const invoice = db.prepare(`
        SELECT i.*, u.telegram_id as user_telegram_id
        FROM invoices i
        JOIN users u ON i.user_id = u.id
        WHERE i.total = ? AND i.status = 'pending' AND i.expires_at > datetime('now')
        ORDER BY i.created_at ASC
        LIMIT 1
      `).get(amount);

      if (!invoice) {
        console.log(`[Watcher] No matching pending invoice for amount: ${amount}`);
        return res.status(404).json({ error: 'No matching invoice found' });
      }

      // 4. Idempotent update: pending -> waiting_approval
      const check = db.prepare("SELECT status FROM invoices WHERE id = ? AND status = 'pending'").get(invoice.id);
      if (!check) {
        return res.status(409).json({ error: 'Invoice already processed' });
      }

      db.prepare("UPDATE invoices SET status = 'waiting_approval', payment_ref = ? WHERE id = ?")
        .run(reference || `WEBHOOK-${Date.now()}`, invoice.id);

      console.log(`[Watcher] Invoice ${invoice.invoice_code} marked as waiting_approval`);

      // 5. Notify admins
      const adminIds = (process.env.ADMIN_IDS || '').split(',').map(id => id.trim()).filter(Boolean);
      const notifyText = `👀 *DEPOSIT BARU MASUK*\n\n` +
        `📋 Invoice: \`${invoice.invoice_code}\`\n` +
        `💰 Nominal: ${invoice.amount}\n` +
        `🔢 Total: ${invoice.total}\n` +
        `📝 Ref: ${reference || '-'}\n\n` +
        `Status: *waiting_approval*\n` +
        `Silakan cek di panel admin untuk approve/reject.`;

      for (const adminId of adminIds) {
        try {
          await bot.sendMessage(adminId, notifyText, { parse_mode: 'MarkdownV2' });
        } catch (err) {
          console.error(`[Watcher] Failed to notify admin ${adminId}:`, err.message);
        }
      }

      // 6. Notify user
      addNotification(invoice.user_id,
        `Pembayaran untuk invoice ${invoice.invoice_code} telah diterima dan sedang menunggu persetujuan admin.`
      );

      res.json({ success: true, invoice_code: invoice.invoice_code, status: 'waiting_approval' });
    } catch (err) {
      console.error('[Watcher] Webhook error:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'nasky-watcher' });
  });

  app.listen(PORT, () => {
    console.log(`[Watcher] Listening on port ${PORT}`);
  });
}
