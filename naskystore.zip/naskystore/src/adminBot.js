import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';
import { db, getOrCreateUser, getSetting, setSetting, getPendingInvoices, getAllUsers, searchUsers,
  getUserByTagId, getStats, addNotification, approveDeposit, rejectDeposit, adjustBalance, backupDatabase } from './database.js';
import { formatRupiah, escapeMarkdown, isAdmin, getAdminMenuKeyboard, getBackKeyboard } from './utils/helpers.js';
import { startWatcher } from './watcher.js';

dotenv.config();

const TOKEN = process.env.BOT_ADMIN_TOKEN;
if (!TOKEN) {
  console.error('[AdminBot] BOT_ADMIN_TOKEN tidak ditemukan di environment');
  process.exit(1);
}

const bot = new TelegramBot(TOKEN, { polling: true });
const adminStates = new Map();

function setState(chatId, state, data = {}) {
  adminStates.set(chatId, { state, data, expiresAt: Date.now() + 600000 });
}

function getState(chatId) {
  const s = adminStates.get(chatId);
  if (!s) return null;
  if (Date.now() > s.expiresAt) {
    adminStates.delete(chatId);
    return null;
  }
  return s;
}

function clearState(chatId) {
  adminStates.delete(chatId);
}

function cleanExpiredStates() {
  const now = Date.now();
  for (const [chatId, state] of adminStates) {
    if (now > state.expiresAt) adminStates.delete(chatId);
  }
}
setInterval(cleanExpiredStates, 120000);

// ── Admin Middleware ──

function requireAdmin(msg, handler) {
  const chatId = msg.chat.id;
  const telegramId = msg.from.id;
  if (!isAdmin(telegramId)) {
    bot.sendMessage(chatId, '⛔ Akses ditolak. Anda bukan admin.');
    console.warn(`[AdminBot] Unauthorized access attempt by ${telegramId}`);
    return;
  }
  handler(chatId, telegramId, msg);
}

// ── /start ──

bot.onText(/\/start/, (msg) => {
  requireAdmin(msg, async (chatId, telegramId) => {
    clearState(chatId);
    await bot.sendMessage(chatId,
      `🔧 *PANEL ADMIN NASKY STORE*

` +
      `Selamat datang, Admin \`${telegramId}\`!
` +
      `Pilih menu di bawah:`,
      { parse_mode: 'MarkdownV2', ...getAdminMenuKeyboard() }
    );
  });
});

// ── Main Message Handler ──

bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;
  const chatId = msg.chat.id;
  const text = msg.text;
  const telegramId = msg.from.id;

  if (!isAdmin(telegramId)) {
    await bot.sendMessage(chatId, '⛔ Akses ditolak.');
    return;
  }

  try {
    const state = getState(chatId);

    if (state) {
      if (text === '⬅️ Kembali') {
        clearState(chatId);
        await bot.sendMessage(chatId, '🏠 Menu admin:', getAdminMenuKeyboard());
        return;
      }

      if (state.state === 'admin_search_user') {
        return handleSearchUser(chatId, telegramId, text);
      }

      if (state.state === 'admin_viewing_user') {
        return handleUserAction(chatId, telegramId, text, state);
      }

      if (state.state === 'admin_adjust_amount') {
        return handleAdjustAmount(chatId, telegramId, text, state);
      }

      if (state.state === 'admin_adjust_reason') {
        return handleAdjustReason(chatId, telegramId, text, state);
      }

      if (state.state === 'admin_awaiting_invoice_code') {
        return handleInvoiceCode(chatId, telegramId, text);
      }

      if (state.state === 'admin_reviewing_invoice') {
        return handleInvoiceAction(chatId, telegramId, text, state);
      }
    }

    // Handle QRIS upload (photo without state)
    if (msg.photo && msg.photo.length > 0) {
      return handleQRISUpload(chatId, telegramId, msg);
    }

    switch (text) {
      case '📊 Statistik':
        await handleStatistik(chatId);
        break;
      case '👥 Data User':
        await handleDataUser(chatId);
        break;
      case '💳 Deposit Pending':
        await handleDepositPending(chatId);
        break;
      case '📦 Total Order':
        await handleTotalOrder(chatId);
        break;
      case '📜 Riwayat':
        await handleAdminRiwayat(chatId);
        break;
      case '📤 Upload QRIS':
        await handleUploadQRIS(chatId);
        break;
      case '🗄 Backup DB':
        await handleBackupDB(chatId);
        break;
      case '🔄 Refresh':
        await bot.sendMessage(chatId, '🔄 Data di-refresh.', getAdminMenuKeyboard());
        break;
      case '⬅️ Kembali':
        await bot.sendMessage(chatId, '🏠 Menu admin:', getAdminMenuKeyboard());
        break;
      default:
        await bot.sendMessage(chatId, '❓ Pilih menu di bawah:', getAdminMenuKeyboard());
    }
  } catch (err) {
    console.error('[AdminBot] Message handler error:', err);
    bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${err.message}`);
  }
});

// ── Menu Handlers ──

async function handleStatistik(chatId) {
  try {
    const stats = getStats();
    let depositBreakdown = '';
    for (const d of stats.depositStatus) {
      depositBreakdown += `   ${d.status}: ${d.count}\n`;
    }

    let orderBreakdown = '';
    for (const o of stats.orderStatus) {
      orderBreakdown += `   ${o.status}: ${o.count}\n`;
    }

    const text = `
📊 *STATISTIK NASKY STORE*

👥 Total User: ${stats.totalUsers}
💰 Total Saldo User: ${escapeMarkdown(formatRupiah(stats.totalBalance))}
💳 Total Deposit (All Time): ${escapeMarkdown(formatRupiah(stats.totalDeposited))}
📦 Total Order: ${stats.totalOrders}
💵 Total Omset: ${escapeMarkdown(formatRupiah(stats.revenue))}

📋 Deposit Breakdown:
${depositBreakdown || '   -'}
📦 Order Breakdown:
${orderBreakdown || '   -'}
    `.trim();

    await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getAdminMenuKeyboard() });
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Gagal memuat statistik: ${err.message}`);
  }
}

async function handleDataUser(chatId) {
  setState(chatId, 'admin_search_user');
  await bot.sendMessage(chatId,
    `👥 *DATA USER*

` +
    `Ketik username, ID Tag, Telegram ID, atau nama user yang ingin dicari.
` +
    `Atau ketik *ALL* untuk melihat 20 user terbaru.`,
    { parse_mode: 'Markdown', ...getBackKeyboard() }
  );
}

async function handleSearchUser(chatId, adminId, text) {
  try {
    let users;
    if (text.toUpperCase() === 'ALL') {
      users = getAllUsers(20);
    } else {
      users = searchUsers(text);
    }

    if (!users || users.length === 0) {
      await bot.sendMessage(chatId, '❌ User tidak ditemukan. Coba kata kunci lain:', getBackKeyboard());
      return;
    }

    if (users.length === 1) {
      await showUserDetail(chatId, adminId, users[0]);
      return;
    }

    let msg = `👥 *HASIL PENCARIAN* (${users.length} user)\n\n`;
    for (let i = 0; i < Math.min(users.length, 15); i++) {
      const u = users[i];
      msg += `${i + 1}. \`${escapeMarkdown(u.tag_id)}\` — ${escapeMarkdown(u.full_name)}\n`;
    }
    msg += '\nKetik nomor untuk melihat detail:';

    setState(chatId, 'admin_viewing_user', { users: users.slice(0, 15), selected: null });
    await bot.sendMessage(chatId, msg, { parse_mode: 'MarkdownV2', ...getBackKeyboard() });
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Error: ${err.message}`);
  }
}

async function handleUserAction(chatId, adminId, text, state) {
  const idx = parseInt(text, 10) - 1;
  if (isNaN(idx) || idx < 0 || idx >= state.data.users.length) {
    await bot.sendMessage(chatId, '❌ Nomor tidak valid. Ketik nomor user:', getBackKeyboard());
    return;
  }

  const user = state.data.users[idx];
  await showUserDetail(chatId, adminId, user);
}

async function showUserDetail(chatId, adminId, user) {
  const text = `
👤 *DETAIL USER*

🆔 Tag: \`${escapeMarkdown(user.tag_id)}\`
📛 Nama: ${escapeMarkdown(user.full_name)}
📱 Username: ${user.username ? '@' + escapeMarkdown(user.username) : '-'}
🪪 Telegram ID: \`${user.telegram_id}\`
💰 Saldo: ${escapeMarkdown(formatRupiah(user.balance))}
💳 Total Deposit: ${escapeMarkdown(formatRupiah(user.total_deposit))}
📦 Total Order: ${user.total_orders}
🗓 Joined: ${user.created_at}
  `.trim();

  setState(chatId, 'admin_adjust_amount', { targetUser: user });
  await bot.sendMessage(chatId, text, {
    parse_mode: 'MarkdownV2',
    reply_markup: {
      keyboard: [
        ['➕ Tambah Saldo', '➖ Kurangi Saldo'],
        ['⬅️ Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleAdjustAmount(chatId, adminId, text, state) {
  if (text === '➕ Tambah Saldo') {
    setState(chatId, 'admin_adjust_reason', { ...state.data, adjustType: 'add', amount: null });
    await bot.sendMessage(chatId, '💰 Masukkan nominal saldo yang akan ditambahkan:', getBackKeyboard());
    return;
  }
  if (text === '➖ Kurangi Saldo') {
    setState(chatId, 'admin_adjust_reason', { ...state.data, adjustType: 'deduct', amount: null });
    await bot.sendMessage(chatId, '💰 Masukkan nominal saldo yang akan dikurangi:', getBackKeyboard());
    return;
  }

  const amount = parseInt(text.replace(/[^\d]/g, ''), 10);
  if (!amount || amount <= 0) {
    await bot.sendMessage(chatId, '❌ Nominal tidak valid. Masukkan angka:', getBackKeyboard());
    return;
  }

  setState(chatId, 'admin_adjust_reason', { ...state.data, amount });
  await bot.sendMessage(chatId, '📝 Masukkan alasan perubahan saldo:', getBackKeyboard());
}

async function handleAdjustReason(chatId, adminId, text, state) {
  const { targetUser, adjustType, amount } = state.data;
  const finalAmount = adjustType === 'add' ? amount : -amount;
  const reason = text.trim();

  try {
    const result = adjustBalance(targetUser.id, finalAmount, adminId.toString(), reason);
    await bot.sendMessage(chatId,
      `✅ *Saldo Diperbarui*

` +
      `User: ${escapeMarkdown(targetUser.tag_id)}
` +
      `Perubahan: ${adjustType === 'add' ? '+' : '-'}${escapeMarkdown(formatRupiah(amount))}
` +
      `Alasan: ${escapeMarkdown(reason)}
` +
      `Saldo Baru: ${escapeMarkdown(formatRupiah(result.balanceAfter))}`,
      { parse_mode: 'MarkdownV2', ...getAdminMenuKeyboard() }
    );

    // Notify user
    addNotification(targetUser.id,
      `Saldo Anda telah di${adjustType === 'add' ? 'tambah' : 'kurangi'} sebesar ${formatRupiah(amount)} oleh admin. Alasan: ${reason}`
    );
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Gagal: ${err.message}`, getAdminMenuKeyboard());
  }
  clearState(chatId);
}

async function handleDepositPending(chatId) {
  const invoices = getPendingInvoices();
  if (!invoices || invoices.length === 0) {
    await bot.sendMessage(chatId, '💳 *Deposit Pending*

-', getAdminMenuKeyboard());
    return;
  }

  let text = `💳 *DEPOSIT PENDING* (${invoices.length})\n\n`;
  for (let i = 0; i < invoices.length; i++) {
    const inv = invoices[i];
    text += `${i + 1}. \`${escapeMarkdown(inv.invoice_code)}\`\n`;
    text += `   User: ${escapeMarkdown(inv.tag_id)} (@${escapeMarkdown(inv.username || '-')})\n`;
    text += `   Nominal: ${escapeMarkdown(formatRupiah(inv.amount))}\n`;
    text += `   Kode Unik: +${inv.unique_code}\n`;
    text += `   Total: ${escapeMarkdown(formatRupiah(inv.total))}\n`;
    text += `   Status: ${inv.status}\n`;
    text += `   ${inv.created_at}\n\n`;
  }

  text += 'Ketik kode invoice untuk review (contoh: INV-XXX):';

  setState(chatId, 'admin_awaiting_invoice_code');
  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getBackKeyboard() });
}

async function handleInvoiceCode(chatId, adminId, text) {
  const invoice = getInvoiceByCode(text.trim());
  if (!invoice) {
    await bot.sendMessage(chatId, '❌ Invoice tidak ditemukan. Coba lagi:', getBackKeyboard());
    return;
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(invoice.user_id);

  const textMsg = `
📋 *DETAIL INVOICE*

🆔 Kode: \`${escapeMarkdown(invoice.invoice_code)}\`
👤 User: ${escapeMarkdown(user.tag_id)} (@${escapeMarkdown(user.username || '-')})
💰 Nominal: ${escapeMarkdown(formatRupiah(invoice.amount))}
🔢 Kode Unik: +${invoice.unique_code}
💵 Total: ${escapeMarkdown(formatRupiah(invoice.total))}
📊 Status: ${invoice.status}
📝 Ref Pembayaran: ${invoice.payment_ref || '-'}
⏰ Expired: ${invoice.expires_at}
🗓 Dibuat: ${invoice.created_at}
  `.trim();

  setState(chatId, 'admin_reviewing_invoice', { invoiceId: invoice.id, invoiceCode: invoice.invoice_code, userId: user.id });
  await bot.sendMessage(chatId, textMsg, {
    parse_mode: 'MarkdownV2',
    reply_markup: {
      keyboard: [
        ['✅ Terima Deposit', '❌ Tolak Deposit'],
        ['⬅️ Kembali']
      ],
      resize_keyboard: true
    }
  });
}

async function handleInvoiceAction(chatId, adminId, text, state) {
  const { invoiceId, invoiceCode, userId } = state.data;

  if (text === '✅ Terima Deposit') {
    try {
      const result = approveDeposit(invoiceId, adminId.toString());
      await bot.sendMessage(chatId,
        `✅ *Deposit Diterima*

` +
        `Invoice: \`${escapeMarkdown(invoiceCode)}\`
` +
        `User: ${escapeMarkdown(result.user.tag_id)}
` +
        `Nominal: ${escapeMarkdown(formatRupiah(result.invoice.amount))}
` +
        `Saldo Baru User: ${escapeMarkdown(formatRupiah(result.balanceAfter))}`,
        { parse_mode: 'MarkdownV2', ...getAdminMenuKeyboard() }
      );

      // Notify user
      addNotification(userId,
        `Deposit Anda ${invoiceCode} sebesar ${formatRupiah(result.invoice.amount)} telah DISETUJUI. Saldo Anda sekarang: ${formatRupiah(result.balanceAfter)}`
      );
    } catch (err) {
      await bot.sendMessage(chatId, `❌ Gagal approve: ${err.message}`, getAdminMenuKeyboard());
    }
    clearState(chatId);
    return;
  }

  if (text === '❌ Tolak Deposit') {
    try {
      rejectDeposit(invoiceId, adminId.toString(), 'Rejected by admin');
      await bot.sendMessage(chatId,
        `❌ *Deposit Ditolak*

Invoice: \`${escapeMarkdown(invoiceCode)}\``,
        { parse_mode: 'MarkdownV2', ...getAdminMenuKeyboard() }
      );

      addNotification(userId,
        `Deposit Anda ${invoiceCode} telah DITOLAK. Silakan hubungi admin untuk informasi lebih lanjut.`
      );
    } catch (err) {
      await bot.sendMessage(chatId, `❌ Gagal reject: ${err.message}`, getAdminMenuKeyboard());
    }
    clearState(chatId);
    return;
  }

  await bot.sendMessage(chatId, '❓ Pilih aksi:', getAdminMenuKeyboard());
}

async function handleTotalOrder(chatId) {
  try {
    const stats = db.prepare('SELECT status, COUNT(*) as count FROM orders GROUP BY status').all();
    const total = db.prepare('SELECT COUNT(*) as count FROM orders').get().count;

    let text = `📦 *TOTAL ORDER*

Total: ${total}\n\n`;
    if (!stats || stats.length === 0) {
      text += '-';
    } else {
      for (const s of stats) {
        text += `${s.status}: ${s.count}\n`;
      }
    }

    await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getAdminMenuKeyboard() });
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Error: ${err.message}`);
  }
}

async function handleAdminRiwayat(chatId) {
  try {
    const txs = db.prepare(`
      SELECT t.*, u.tag_id, u.username
      FROM transactions t
      JOIN users u ON t.user_id = u.id
      ORDER BY t.created_at DESC
      LIMIT 20
    `).all();

    if (!txs || txs.length === 0) {
      await bot.sendMessage(chatId, '📜 *Riwayat*

-', getAdminMenuKeyboard());
      return;
    }

    let text = '📜 *RIWAYAT TRANSAKSI TERBARU*\n\n';
    for (const tx of txs) {
      const sign = tx.amount >= 0 ? '+' : '';
      text += `${tx.type.toUpperCase()} — \`${escapeMarkdown(tx.reference || '-')}\`\n`;
      text += `   User: ${escapeMarkdown(tx.tag_id)}\n`;
      text += `   Nominal: ${sign}${escapeMarkdown(formatRupiah(tx.amount))}\n`;
      text += `   ${tx.created_at}\n\n`;
    }

    await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getAdminMenuKeyboard() });
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Error: ${err.message}`);
  }
}

async function handleUploadQRIS(chatId) {
  setState(chatId, 'admin_upload_qris');
  await bot.sendMessage(chatId,
    `📤 *UPLOAD QRIS*

` +
    `Kirim gambar QRIS dengan *caption* berisi string QRIS static.
` +
    `Caption akan disimpan sebagai DEFAULT_QRIS_STATIC.

` +
    `Contoh caption:
` +
    `\`00020101021126660014ID.LINKAJA...\``,
    { parse_mode: 'Markdown', ...getBackKeyboard() }
  );
}

async function handleQRISUpload(chatId, adminId, msg) {
  const state = getState(chatId);
  if (!state || state.state !== 'admin_upload_qris') {
    await bot.sendMessage(chatId, '❌ Kirim /start lalu pilih 📤 Upload QRIS terlebih dahulu.');
    return;
  }

  const caption = msg.caption || msg.text || '';
  if (!caption || caption.trim().length < 10) {
    await bot.sendMessage(chatId, '❌ Caption tidak valid. Kirim ulang gambar dengan caption berisi string QRIS.');
    return;
  }

  try {
    setSetting('DEFAULT_QRIS_STATIC', caption.trim());
    await bot.sendMessage(chatId,
      `✅ *QRIS Berhasil Diupload*

` +
      `String QRIS telah disimpan.
` +
      `Panjang: ${caption.trim().length} karakter`,
      { parse_mode: 'Markdown', ...getAdminMenuKeyboard() }
    );
    clearState(chatId);
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Gagal menyimpan QRIS: ${err.message}`);
  }
}

async function handleBackupDB(chatId) {
  try {
    const backupDir = process.env.BACKUP_DIR || '/root/nasky-data/backups';
    const fs = await import('fs');
    const path = await import('path');

    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }

    const now = new Date();
    const filename = `nasky-backup-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}-${String(now.getSeconds()).padStart(2, '0')}.sqlite`;
    const filePath = path.join(backupDir, filename);

    await backupDatabase(filePath);
    const stats = fs.statSync(filePath);
    const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);

    await bot.sendMessage(chatId,
      `✅ *Backup Berhasil*

` +
      `📁 File: \`${filename}\`
` +
      `📦 Ukuran: ${sizeMB} MB
` +
      `🗓 Waktu: ${now.toISOString()}`,
      { parse_mode: 'MarkdownV2', ...getAdminMenuKeyboard() }
    );
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Backup gagal: ${err.message}`);
  }
}

// ── Start Watcher ──

startWatcher(bot, db);

// ── Error Handling ──

bot.on('polling_error', (err) => {
  console.error('[AdminBot] Polling error:', err.message);
});

bot.on('error', (err) => {
  console.error('[AdminBot] Bot error:', err);
});

console.log('[AdminBot] Started successfully');
