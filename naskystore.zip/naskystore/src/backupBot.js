import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';
import { createReadStream, existsSync, mkdirSync, readdirSync, statSync, unlinkSync } from 'fs';
import { join, basename } from 'path';
import { backupDatabase } from './database.js';

dotenv.config();

const TOKEN = process.env.BACKUP_BOT_TOKEN;
const CHAT_ID = process.env.BACKUP_CHAT_ID;
const BACKUP_DIR = process.env.BACKUP_DIR || '/root/nasky-data/backups';
const INTERVAL = parseInt(process.env.BACKUP_INTERVAL_MS || '3600000', 10);
const MAX_BACKUPS = parseInt(process.env.MAX_BACKUPS || '24', 10);

if (!TOKEN) {
  console.error('[BackupBot] BACKUP_BOT_TOKEN tidak ditemukan');
  process.exit(1);
}

const bot = new TelegramBot(TOKEN, { polling: true });

function ensureBackupDir() {
  if (!existsSync(BACKUP_DIR)) {
    mkdirSync(BACKUP_DIR, { recursive: true });
    console.log(`[BackupBot] Created backup dir: ${BACKUP_DIR}`);
  }
}

function getBackupFiles() {
  ensureBackupDir();
  return readdirSync(BACKUP_DIR)
    .filter(f => f.endsWith('.sqlite'))
    .map(f => {
      const p = join(BACKUP_DIR, f);
      const s = statSync(p);
      return { name: f, path: p, size: s.size, mtime: s.mtime };
    })
    .sort((a, b) => b.mtime - a.mtime);
}

function rotateBackups() {
  const files = getBackupFiles();
  if (files.length > MAX_BACKUPS) {
    const toDelete = files.slice(MAX_BACKUPS);
    for (const f of toDelete) {
      try {
        unlinkSync(f.path);
        console.log(`[BackupBot] Rotated: ${f.name}`);
      } catch (err) {
        console.error(`[BackupBot] Failed to delete ${f.name}:`, err.message);
      }
    }
  }
}

async function performBackup(manual = false) {
  try {
    ensureBackupDir();

    const now = new Date();
    const filename = `nasky-backup-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}-${String(now.getSeconds()).padStart(2, '0')}.sqlite`;
    const filePath = join(BACKUP_DIR, filename);

    console.log(`[BackupBot] Starting backup: ${filename}`);
    await backupDatabase(filePath);

    const stats = statSync(filePath);
    const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);

    // Get DB stats
    const { db } = await import('./database.js');
    const userCount = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
    const orderCount = db.prepare('SELECT COUNT(*) as c FROM orders').get().c;
    const txCount = db.prepare('SELECT COUNT(*) as c FROM transactions').get().c;

    const caption = `
🗄 *DATABASE BACKUP*

📁 File: \`${filename}\`
📦 Ukuran: ${sizeMB} MB
🗓 Waktu: ${now.toISOString()}

📊 DB Stats:
• Users: ${userCount}
• Orders: ${orderCount}
• Transactions: ${txCount}

${manual ? '✅ Manual backup' : '🤖 Auto backup'}
    `.trim();

    if (CHAT_ID) {
      await bot.sendDocument(CHAT_ID, createReadStream(filePath), {
        caption,
        parse_mode: 'MarkdownV2'
      });
      console.log(`[BackupBot] Sent backup to chat ${CHAT_ID}`);
    }

    rotateBackups();
    return { success: true, filename, sizeMB };
  } catch (err) {
    console.error('[BackupBot] Backup failed:', err);
    if (CHAT_ID && manual) {
      await bot.sendMessage(CHAT_ID, `❌ Backup gagal: ${err.message}`);
    }
    return { success: false, error: err.message };
  }
}

// ── Auto Backup ──

setInterval(() => {
  performBackup(false);
}, INTERVAL);

// Initial backup on startup
setTimeout(() => performBackup(false), 5000);

// ── Commands ──

bot.onText(/\/backup/, async (msg) => {
  const chatId = msg.chat.id;
  if (CHAT_ID && chatId.toString() !== CHAT_ID) {
    await bot.sendMessage(chatId, '⛔ Akses ditolak.');
    return;
  }
  await bot.sendMessage(chatId, '🗄 Memulai backup manual...');
  const result = await performBackup(true);
  if (!result.success) {
    await bot.sendMessage(chatId, `❌ Backup gagal: ${result.error}`);
  }
});

bot.onText(/\/listbackups/, async (msg) => {
  const chatId = msg.chat.id;
  if (CHAT_ID && chatId.toString() !== CHAT_ID) {
    await bot.sendMessage(chatId, '⛔ Akses ditolak.');
    return;
  }

  const files = getBackupFiles();
  if (files.length === 0) {
    await bot.sendMessage(chatId, '📂 Tidak ada file backup.');
    return;
  }

  let text = '📂 *DAFTAR BACKUP*\n\n';
  for (const f of files) {
    const sizeMB = (f.size / (1024 * 1024)).toFixed(2);
    text += `📁 \`${f.name}\`\n`;
    text += `   📦 ${sizeMB} MB — ${f.mtime.toISOString()}\n\n`;
  }

  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2' });
});

bot.onText(/\/deletebackup (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (CHAT_ID && chatId.toString() !== CHAT_ID) {
    await bot.sendMessage(chatId, '⛔ Akses ditolak.');
    return;
  }

  const filename = match[1].trim();
  const filePath = join(BACKUP_DIR, filename);

  if (!existsSync(filePath)) {
    await bot.sendMessage(chatId, `❌ File \`${filename}\` tidak ditemukan.`, { parse_mode: 'MarkdownV2' });
    return;
  }

  try {
    unlinkSync(filePath);
    await bot.sendMessage(chatId, `✅ File \`${filename}\` dihapus.`, { parse_mode: 'MarkdownV2' });
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Gagal menghapus: ${err.message}`);
  }
});

// ── Error Handling ──

bot.on('polling_error', (err) => {
  console.error('[BackupBot] Polling error:', err.message);
});

bot.on('error', (err) => {
  console.error('[BackupBot] Bot error:', err);
});

console.log('[BackupBot] Started successfully');
