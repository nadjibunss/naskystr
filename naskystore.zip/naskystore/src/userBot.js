import TelegramBot from 'node-telegram-bot-api';
import dotenv from 'dotenv';
import { db, getOrCreateUser, getSetting, logUserAction, addNotification, getUnreadNotifications,
  getUserOrders, getUserInvoices, getUserTransactions, getReferralCount, getReferrals, createInvoice, cancelOrder } from './database.js';
import { generateQRISImage } from './utils/qris.js';
import { refreshLeaderboard, getLeaderboard } from './utils/leaderboard.js';
import { generateInvoiceCode, generateUniqueCode, getNextOrderRef, formatRupiah, escapeMarkdown,
  getMainMenuKeyboard, getSaldoMenuKeyboard, getTopUpAmountKeyboard, getCancelKeyboard, getBackKeyboard, parseAmount } from './utils/helpers.js';

dotenv.config();

const TOKEN = process.env.BOT_USER_TOKEN;
if (!TOKEN) {
  console.error('[UserBot] BOT_USER_TOKEN tidak ditemukan di environment');
  process.exit(1);
}

const bot = new TelegramBot(TOKEN, { polling: true });
const userStates = new Map();
const OTP_ENABLED = process.env.OTP_PROVIDER_ENABLED === 'true';

function setState(chatId, state, data = {}) {
  userStates.set(chatId, { state, data, expiresAt: Date.now() + 300000 });
}

function getState(chatId) {
  const s = userStates.get(chatId);
  if (!s) return null;
  if (Date.now() > s.expiresAt) {
    userStates.delete(chatId);
    return null;
  }
  return s;
}

function clearState(chatId) {
  userStates.delete(chatId);
}

function cleanExpiredStates() {
  const now = Date.now();
  for (const [chatId, state] of userStates) {
    if (now > state.expiresAt) userStates.delete(chatId);
  }
}
setInterval(cleanExpiredStates, 60000);

// ── Notification Checker ──

async function checkAndSendNotifications(chatId, userId) {
  try {
    const notifs = getUnreadNotifications(userId);
    for (const n of notifs) {
      await bot.sendMessage(chatId, `📢 *Notifikasi*\n\n${escapeMarkdown(n.message)}`, {
        parse_mode: 'MarkdownV2',
        reply_markup: { remove_keyboard: true }
      });
    }
  } catch (err) {
    console.error('[UserBot] Notification error:', err);
  }
}

// ── /start ──

bot.onText(/\/start/, async (msg) => {
  try {
    const chatId = msg.chat.id;
    const user = getOrCreateUser(msg.from);
    clearState(chatId);

    const welcomeText = `
🌟 *SELAMAT DATANG DI NASKY STORE* 🌟

👤 ID Tag: \`${escapeMarkdown(user.tag_id)}\`
💰 Saldo: ${escapeMarkdown(formatRupiah(user.balance))}

Silakan pilih menu di bawah ini:
    `.trim();

    await bot.sendMessage(chatId, welcomeText, {
      parse_mode: 'MarkdownV2',
      ...getMainMenuKeyboard()
    });

    logUserAction(user.id, 'start', `User ${msg.from.id} started bot`);
  } catch (err) {
    console.error('[UserBot] /start error:', err);
    bot.sendMessage(msg.chat.id, '❌ Terjadi kesalahan. Silakan coba lagi.');
  }
});

// ── Main Message Handler ──

bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;
  const chatId = msg.chat.id;
  const text = msg.text;

  try {
    const user = getOrCreateUser(msg.from);
    await checkAndSendNotifications(chatId, user.id);

    const state = getState(chatId);

    // Handle states first
    if (state) {
      if (text === '❌ Batal' || text === '⬅️ Kembali') {
        clearState(chatId);
        if (state.state.startsWith('topup_')) {
          await bot.sendMessage(chatId, '✅ Dibatalkan.', getSaldoMenuKeyboard());
        } else if (state.state.startsWith('otp_')) {
          await bot.sendMessage(chatId, '✅ Dibatalkan.', getMainMenuKeyboard());
        } else {
          await bot.sendMessage(chatId, '✅ Dibatalkan.', getMainMenuKeyboard());
        }
        return;
      }

      if (state.state === 'awaiting_custom_amount') {
        return handleCustomAmount(chatId, user, text);
      }

      if (state.state === 'otp_select_service') {
        return handleOTPService(chatId, user, text);
      }

      if (state.state === 'otp_select_country') {
        return handleOTPCountry(chatId, user, text);
      }

      if (state.state === 'otp_enter_phone') {
        return handleOTPPhone(chatId, user, text);
      }

      if (state.state === 'cancel_order_select') {
        return handleCancelOrderSelect(chatId, user, text);
      }
    }

    // Handle menu buttons
    switch (text) {
      case '🛒 Beli OTP':
        await handleBeliOTP(chatId, user);
        break;
      case '👤 Profil':
        await handleProfil(chatId, user);
        break;
      case '💰 Saldo':
        await handleSaldo(chatId, user);
        break;
      case '👥 Referral':
        await handleReferral(chatId, user);
        break;
      case '🏆 Leaderboard':
        await handleLeaderboard(chatId, user);
        break;
      case '📋 Order Aktif':
        await handleOrderAktif(chatId, user);
        break;
      case '📜 Riwayat':
        await handleRiwayat(chatId, user);
        break;
      case '💳 Top Up':
        await handleTopUp(chatId, user);
        break;
      case '📜 History Top Up':
        await handleHistoryTopUp(chatId, user);
        break;
      case '⬅️ Kembali':
        await bot.sendMessage(chatId, '🏠 Menu utama:', getMainMenuKeyboard());
        break;
      case 'Rp 10.000':
        await processTopUp(chatId, user, 10000);
        break;
      case 'Rp 25.000':
        await processTopUp(chatId, user, 25000);
        break;
      case 'Rp 50.000':
        await processTopUp(chatId, user, 50000);
        break;
      case 'Rp 100.000':
        await processTopUp(chatId, user, 100000);
        break;
      case '✏️ Nominal Custom':
        setState(chatId, 'awaiting_custom_amount');
        await bot.sendMessage(chatId,
          '✏️ Masukkan nominal top up (min Rp 10.000, max Rp 10.000.000):',
          getCancelKeyboard());
        break;
      default:
        // If user sends random text, show main menu
        await bot.sendMessage(chatId, '❓ Pilih menu di bawah:', getMainMenuKeyboard());
    }
  } catch (err) {
    console.error('[UserBot] Message handler error:', err);
    bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${err.message}`);
  }
});

// ── Menu Handlers ──

async function handleBeliOTP(chatId, user) {
  if (!OTP_ENABLED) {
    await bot.sendMessage(chatId,
      `🚧 *Coming Soon* 🚧

` +
      `Fitur pembelian OTP belum aktif.
` +
      `Provider belum dikonfigurasi atau sedang dalam maintenance.

` +
      `Silakan hubungi admin untuk informasi lebih lanjut.`,
      { parse_mode: 'Markdown', ...getMainMenuKeyboard() }
    );
    logUserAction(user.id, 'otp_attempt_disabled');
    return;
  }

  // OTP Provider active - show service selection
  setState(chatId, 'otp_select_service', {});
  await bot.sendMessage(chatId,
    `🛒 *Beli OTP*

` +
    `Pilih layanan:
` +
    `1️⃣ WhatsApp
` +
    `2️⃣ Telegram
` +
    `3️⃣ Google
` +
    `4️⃣ Lainnya

` +
    `Ketik nomor layanan yang diinginkan:`,
    { parse_mode: 'Markdown', ...getCancelKeyboard() }
  );
}

async function handleOTPService(chatId, user, text) {
  const services = { '1': 'WhatsApp', '2': 'Telegram', '3': 'Google', '4': 'Lainnya' };
  const service = services[text];
  if (!service) {
    await bot.sendMessage(chatId, '❌ Pilihan tidak valid. Ketik 1-4:', getCancelKeyboard());
    return;
  }

  setState(chatId, 'otp_select_country', { service });
  await bot.sendMessage(chatId,
    `🌍 *Pilih Negara*

` +
    `1️⃣ Indonesia (+62)
` +
    `2️⃣ USA (+1)
` +
    `3️⃣ UK (+44)
` +
    `4️⃣ Lainnya

` +
    `Ketik nomor negara:`,
    { parse_mode: 'Markdown', ...getCancelKeyboard() }
  );
}

async function handleOTPCountry(chatId, user, text) {
  const countries = { '1': 'Indonesia', '2': 'USA', '3': 'UK', '4': 'Lainnya' };
  const country = countries[text];
  if (!country) {
    await bot.sendMessage(chatId, '❌ Pilihan tidak valid. Ketik 1-4:', getCancelKeyboard());
    return;
  }

  const state = getState(chatId);
  setState(chatId, 'otp_enter_phone', { ...state.data, country });
  await bot.sendMessage(chatId,
    `📱 *Masukkan Nomor Telepon*

` +
    `Masukkan nomor telepon target (dengan kode negara):
` +
    `Contoh: +6281234567890`,
    { parse_mode: 'Markdown', ...getCancelKeyboard() }
  );
}

async function handleOTPPhone(chatId, user, text) {
  const phone = text.trim();
  if (!phone.match(/^\+?[\d\s\-]{8,20}$/)) {
    await bot.sendMessage(chatId, '❌ Format nomor tidak valid. Contoh: +6281234567890', getCancelKeyboard());
    return;
  }

  const state = getState(chatId);
  const price = 5000; // Mock price - would come from provider

  if (user.balance < price) {
    await bot.sendMessage(chatId,
      `❌ Saldo tidak cukup.
` +
      `Harga: ${formatRupiah(price)}
` +
      `Saldo Anda: ${formatRupiah(user.balance)}

` +
      `Silakan top up terlebih dahulu.`,
      getMainMenuKeyboard()
    );
    clearState(chatId);
    return;
  }

  try {
    const orderRef = getNextOrderRef();
    const expiresAt = new Date(Date.now() + 600000).toISOString(); // 10 min expiry

    const order = createOrder(user.id, orderRef, 'nasky-otp', state.data.service, state.data.country, phone, price, expiresAt);

    // Deduct balance
    const balanceBefore = user.balance;
    const balanceAfter = balanceBefore - price;
    db.prepare('UPDATE users SET balance = ? WHERE id = ?').run(balanceAfter, user.id);
    db.prepare(`
      INSERT INTO transactions (user_id, type, reference, amount, balance_before, balance_after)
      VALUES (?, 'purchase', ?, ?, ?, ?)
    `).run(user.id, orderRef, -price, balanceBefore, balanceAfter);

    await bot.sendMessage(chatId,
      `✅ *Order Berhasil Dibuat!*

` +
      `📋 Ref: \`${orderRef}\`
` +
      `🔧 Layanan: ${state.data.service}
` +
      `🌍 Negara: ${state.data.country}
` +
      `📱 Nomor: ${phone}
` +
      `💰 Harga: ${formatRupiah(price)}
` +
      `⏰ Expired: 10 menit

` +
      `Order sedang diproses. Anda akan menerima notifikasi jika OTP diterima.`,
      { parse_mode: 'Markdown', ...getMainMenuKeyboard() }
    );

    logUserAction(user.id, 'create_order', `Created order ${orderRef}`);
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Gagal membuat order: ${err.message}`, getMainMenuKeyboard());
  }
  clearState(chatId);
}

async function handleProfil(chatId, user) {
  const text = `
👤 *PROFIL ANDA*

🆔 ID Tag: \`${escapeMarkdown(user.tag_id)}\`
📛 Username: ${user.username ? '@' + escapeMarkdown(user.username) : '-'}
🪪 Telegram ID: \`${user.telegram_id}\`
📛 Nama: ${escapeMarkdown(user.full_name)}

💰 Saldo Saat Ini: ${escapeMarkdown(formatRupiah(user.balance))}
💳 Total Deposit: ${escapeMarkdown(formatRupiah(user.total_deposit))}
📦 Total Order: ${user.total_orders}
🗓 Bergabung: ${user.created_at}
  `.trim();

  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getMainMenuKeyboard() });
}

async function handleSaldo(chatId, user) {
  const text = `
💰 *MENU SALDO*

Saldo Anda: ${escapeMarkdown(formatRupiah(user.balance))}

Pilih opsi di bawah:
  `.trim();

  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getSaldoMenuKeyboard() });
}

async function handleTopUp(chatId, user) {
  setState(chatId, 'topup_select_amount');
  await bot.sendMessage(chatId,
    `💳 *TOP UP SALDO*

` +
    `Pilih nominal atau masukkan custom:
` +
    `• Min: Rp 10.000
` +
    `• Max: Rp 10.000.000`,
    { parse_mode: 'Markdown', ...getTopUpAmountKeyboard() }
  );
}

async function handleCustomAmount(chatId, user, text) {
  const amount = parseAmount(text);
  if (!amount || amount < 10000) {
    await bot.sendMessage(chatId, '❌ Minimal top up Rp 10.000. Masukkan nominal:', getCancelKeyboard());
    return;
  }
  if (amount > 10000000) {
    await bot.sendMessage(chatId, '❌ Maksimal top up Rp 10.000.000. Masukkan nominal:', getCancelKeyboard());
    return;
  }
  await processTopUp(chatId, user, amount);
  clearState(chatId);
}

async function processTopUp(chatId, user, amount) {
  try {
    const staticQris = getSetting('DEFAULT_QRIS_STATIC');
    if (!staticQris) {
      await bot.sendMessage(chatId,
        `⚠️ *QRIS Belum Dikonfigurasi*

` +
        `Sistem pembayaran QRIS belum diatur oleh admin.
` +
        `Silakan hubungi admin untuk informasi top up manual.`,
        { parse_mode: 'Markdown', ...getSaldoMenuKeyboard() }
      );
      return;
    }

    // Generate unique code and ensure uniqueness among pending invoices
    let uniqueCode, total;
    let attempts = 0;
    do {
      uniqueCode = generateUniqueCode();
      total = amount + uniqueCode;
      const existing = db.prepare('SELECT 1 FROM invoices WHERE total = ? AND status = ?').get(total, 'pending');
      if (!existing) break;
      attempts++;
    } while (attempts < 100);

    if (attempts >= 100) {
      throw new Error('Tidak dapat generate kode unik. Silakan coba lagi.');
    }

    const invoiceCode = generateInvoiceCode();
    const ttlSeconds = parseInt(process.env.QRIS_TTL_SECONDS || '180', 10);
    const expiresAt = new Date(Date.now() + ttlSeconds * 1000).toISOString();

    const invoice = createInvoice(user.id, amount, uniqueCode, total, invoiceCode, expiresAt);

    // Generate QRIS image
    const qrBuffer = await generateQRISImage(staticQris);

    const caption = `
💳 *INVOICE TOP UP*

📋 Kode: \`${escapeMarkdown(invoiceCode)}\`
💰 Nominal: ${escapeMarkdown(formatRupiah(amount))}
🔢 Kode Unik: +${uniqueCode}
💵 *Total Transfer: ${escapeMarkdown(formatRupiah(total))}*
⏰ Berlaku hingga: ${expiresAt.replace('T', ' ').substring(0, 19)}

📌 *Petunjuk Pembayaran:*
1️⃣ Scan QRIS di atas
2️⃣ Transfer *tepat* sebesar ${escapeMarkdown(formatRupiah(total))}
3️⃣ Tunggu konfirmasi dari admin
4️⃣ Saldo akan otomatis masuk setelah di-approve

⚠️ *PENTING:* Transfer tepat sesuai nominal unik agar pembayaran dapat diproses.
    `.trim();

    await bot.sendPhoto(chatId, qrBuffer, {
      caption,
      parse_mode: 'MarkdownV2',
      ...getCancelKeyboard()
    });

    logUserAction(user.id, 'create_invoice', `Invoice ${invoiceCode} for ${amount}`);
  } catch (err) {
    console.error('[UserBot] processTopUp error:', err);
    await bot.sendMessage(chatId, `❌ Gagal membuat invoice: ${err.message}`, getSaldoMenuKeyboard());
  }
}

async function handleHistoryTopUp(chatId, user) {
  const invoices = getUserInvoices(user.id);
  if (!invoices || invoices.length === 0) {
    await bot.sendMessage(chatId, '📜 History Top Up:

-', getSaldoMenuKeyboard());
    return;
  }

  let text = '📜 *HISTORY TOP UP*

';
  for (const inv of invoices.slice(0, 20)) {
    const statusEmoji = {
      'pending': '⏳',
      'waiting_approval': '👀',
      'approved': '✅',
      'rejected': '❌',
      'cancelled': '🚫',
      'expired': '⌛'
    }[inv.status] || '❓';

    text += `${statusEmoji} \`${escapeMarkdown(inv.invoice_code)}\`
`;
    text += `   Nominal: ${escapeMarkdown(formatRupiah(inv.amount))}
`;
    text += `   Total: ${escapeMarkdown(formatRupiah(inv.total))}
`;
    text += `   Status: ${inv.status}
`;
    text += `   Ref: ${inv.payment_ref || '-'}
`;
    text += `   ${inv.created_at}

`;
  }

  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getSaldoMenuKeyboard() });
}

async function handleReferral(chatId, user) {
  const count = getReferralCount(user.id);
  const referrals = getReferrals(user.id);

  let text = `
👥 *PROGRAM REFERRAL*

🔗 Kode Referral Anda:
\`${escapeMarkdown(user.referral_code)}\`

👤 Total Referral: ${count}

  `.trim();

  if (referrals.length > 0) {
    text += '\n📋 *Daftar Referral:*\n';
    for (const ref of referrals.slice(0, 10)) {
      text += `• ${escapeMarkdown(ref.tag_id)} — ${escapeMarkdown(ref.full_name)}\n`;
    }
    if (referrals.length > 10) text += `... dan ${referrals.length - 10} lainnya\n`;
  }

  text += '\n💡 Bagikan kode referral Anda ke teman-teman!';

  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getMainMenuKeyboard() });
}

async function handleLeaderboard(chatId, user) {
  const board = getLeaderboard();
  if (!board || board.length === 0) {
    await bot.sendMessage(chatId, '🏆 Leaderboard:

-', getMainMenuKeyboard());
    return;
  }

  let text = '🏆 *LEADERBOARD* 🏆

';
  const medals = ['🥇', '🥈', '🥉'];
  for (const entry of board) {
    const medal = entry.rank <= 3 ? medals[entry.rank - 1] : `${entry.rank}.`;
    const name = entry.username ? `@${entry.username}` : entry.full_name;
    text += `${medal} ${escapeMarkdown(name)} — ${escapeMarkdown(formatRupiah(entry.score))}
`;
  }

  text += '
🔄 Auto-refresh setiap 5 menit';

  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getMainMenuKeyboard() });
}

async function handleOrderAktif(chatId, user) {
  const orders = getUserOrders(user.id, ['active', 'processing', 'waiting']);

  if (!orders || orders.length === 0) {
    let text = '📋 *ORDER AKTIF*

';
    if (!OTP_ENABLED) {
      text += '-\n\n🚧 Fitur OTP belum aktif.';
    } else {
      text += '-';
    }
    await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getMainMenuKeyboard() });
    return;
  }

  let text = '📋 *ORDER AKTIF*

';
  const orderList = [];
  for (const order of orders.slice(0, 10)) {
    text += `📦 \`${escapeMarkdown(order.order_ref)}\`
`;
    text += `   Layanan: ${order.service || '-'}
`;
    text += `   Negara: ${order.country || '-'}
`;
    text += `   Status: ${order.status}
`;
    text += `   Harga: ${escapeMarkdown(formatRupiah(order.price))}

`;
    orderList.push(order.order_ref);
  }

  text += 'Ketik nomor urut order untuk membatalkan (contoh: 1), atau klik ⬅️ Kembali:';

  setState(chatId, 'cancel_order_select', { orders: orderList });
  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getCancelKeyboard() });
}

async function handleCancelOrderSelect(chatId, user, text) {
  const state = getState(chatId);
  const idx = parseInt(text, 10) - 1;
  if (isNaN(idx) || idx < 0 || idx >= state.data.orders.length) {
    await bot.sendMessage(chatId, '❌ Nomor tidak valid. Ketik nomor urut order:', getCancelKeyboard());
    return;
  }

  const orderRef = state.data.orders[idx];
  const order = getOrderByRef(orderRef);
  if (!order) {
    await bot.sendMessage(chatId, '❌ Order tidak ditemukan.', getMainMenuKeyboard());
    clearState(chatId);
    return;
  }

  try {
    cancelOrder(order.id, user.id);
    await bot.sendMessage(chatId,
      `✅ Order \`${escapeMarkdown(orderRef)}\` berhasil dibatalkan.
` +
      (order.price > 0 ? `💰 Refund: ${escapeMarkdown(formatRupiah(order.price))}` : ''),
      { parse_mode: 'MarkdownV2', ...getMainMenuKeyboard() }
    );
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Gagal membatalkan: ${err.message}`, getMainMenuKeyboard());
  }
  clearState(chatId);
}

async function handleRiwayat(chatId, user) {
  const transactions = getUserTransactions(user.id);
  if (!transactions || transactions.length === 0) {
    await bot.sendMessage(chatId, '📜 Riwayat:

-', getMainMenuKeyboard());
    return;
  }

  let text = '📜 *RIWAYAT TRANSAKSI*

';
  for (const tx of transactions.slice(0, 20)) {
    const emoji = { 'deposit': '💳', 'purchase': '🛒', 'cancel': '🚫', 'adjustment': '⚙️' }[tx.type] || '📝';
    const sign = tx.amount >= 0 ? '+' : '';
    text += `${emoji} ${tx.type.toUpperCase()}
`;
    text += `   Ref: ${escapeMarkdown(tx.reference || '-')}
`;
    text += `   Nominal: ${sign}${escapeMarkdown(formatRupiah(tx.amount))}
`;
    text += `   Saldo: ${escapeMarkdown(formatRupiah(tx.balance_before))} → ${escapeMarkdown(formatRupiah(tx.balance_after))}
`;
    text += `   ${tx.created_at}

`;
  }

  await bot.sendMessage(chatId, text, { parse_mode: 'MarkdownV2', ...getMainMenuKeyboard() });
}

// ── Leaderboard Auto-Refresh ──

setInterval(() => {
  try {
    refreshLeaderboard();
  } catch (err) {
    console.error('[UserBot] Leaderboard refresh error:', err);
  }
}, 5 * 60 * 1000);

// Initial refresh
refreshLeaderboard();

// ── Error Handling ──

bot.on('polling_error', (err) => {
  console.error('[UserBot] Polling error:', err.message);
});

bot.on('error', (err) => {
  console.error('[UserBot] Bot error:', err);
});

console.log('[UserBot] Started successfully');
