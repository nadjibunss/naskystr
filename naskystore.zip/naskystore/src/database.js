import Database from 'better-sqlite3';
import { mkdirSync, existsSync } from 'fs';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

dotenv.config();

const dbPath = process.env.DB_PATH || '/root/nasky-data/nasky.sqlite';
const dbDir = dirname(dbPath);

if (!existsSync(dbDir)) {
  mkdirSync(dbDir, { recursive: true });
}

export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');

// ── Idempotent Migrations ──

function migrate() {
  // users
  db.prepare(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      telegram_id TEXT UNIQUE NOT NULL,
      tag_id TEXT UNIQUE NOT NULL,
      username TEXT,
      full_name TEXT,
      balance INTEGER DEFAULT 0,
      total_deposit INTEGER DEFAULT 0,
      total_orders INTEGER DEFAULT 0,
      referral_code TEXT UNIQUE NOT NULL,
      referred_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `).run();

  db.prepare(`CREATE INDEX IF NOT EXISTS idx_users_telegram ON users(telegram_id)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_users_tag ON users(tag_id)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_users_referral ON users(referral_code)`).run();

  // settings
  db.prepare(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    )
  `).run();

  // invoices
  db.prepare(`
    CREATE TABLE IF NOT EXISTS invoices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_code TEXT UNIQUE NOT NULL,
      user_id INTEGER NOT NULL,
      amount INTEGER NOT NULL,
      unique_code INTEGER NOT NULL,
      total INTEGER NOT NULL,
      status TEXT DEFAULT 'pending',
      payment_ref TEXT,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `).run();

  db.prepare(`CREATE INDEX IF NOT EXISTS idx_invoices_user ON invoices(user_id)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_invoices_created ON invoices(created_at)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_invoices_total ON invoices(total)`).run();

  // orders
  db.prepare(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_ref TEXT UNIQUE NOT NULL,
      user_id INTEGER NOT NULL,
      provider TEXT,
      service TEXT,
      country TEXT,
      phone TEXT,
      price INTEGER,
      status TEXT DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      expires_at DATETIME,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `).run();

  db.prepare(`CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_orders_ref ON orders(order_ref)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at)`).run();

  // transactions
  db.prepare(`
    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL,
      reference TEXT,
      amount INTEGER NOT NULL,
      balance_before INTEGER NOT NULL,
      balance_after INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `).run();

  db.prepare(`CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_transactions_created ON transactions(created_at)`).run();

  // user_logs
  db.prepare(`
    CREATE TABLE IF NOT EXISTS user_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      detail TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `).run();

  db.prepare(`CREATE INDEX IF NOT EXISTS idx_user_logs_user ON user_logs(user_id)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_user_logs_created ON user_logs(created_at)`).run();

  // admin_actions
  db.prepare(`
    CREATE TABLE IF NOT EXISTS admin_actions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admin_id TEXT NOT NULL,
      action TEXT NOT NULL,
      target_user_id INTEGER,
      detail TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `).run();

  db.prepare(`CREATE INDEX IF NOT EXISTS idx_admin_actions_admin ON admin_actions(admin_id)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_admin_actions_target ON admin_actions(target_user_id)`).run();
  db.prepare(`CREATE INDEX IF NOT EXISTS idx_admin_actions_created ON admin_actions(created_at)`).run();

  // leaderboard_cache
  db.prepare(`
    CREATE TABLE IF NOT EXISTS leaderboard_cache (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL UNIQUE,
      rank INTEGER NOT NULL,
      score INTEGER NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `).run();

  db.prepare(`CREATE INDEX IF NOT EXISTS idx_leaderboard_rank ON leaderboard_cache(rank)`).run();

  // notifications (for cross-bot communication)
  db.prepare(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `).run();

  db.prepare(`CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read)`).run();

  console.log('[DB] Migrations applied successfully');
}

migrate();

// ── Helper Functions ──

export function getOrCreateUser(telegramUser) {
  const { id: telegram_id, username, first_name, last_name } = telegramUser;
  const full_name = [first_name, last_name].filter(Boolean).join(' ') || 'Unknown';

  let user = db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(telegram_id.toString());
  if (user) {
    // Update username and name if changed
    db.prepare('UPDATE users SET username = ?, full_name = ? WHERE id = ?')
      .run(username || null, full_name, user.id);
    return db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
  }

  // Create new user
  const tagId = generateTagIdInternal();
  const referralCode = tagId;

  const result = db.prepare(`
    INSERT INTO users (telegram_id, tag_id, username, full_name, referral_code)
    VALUES (?, ?, ?, ?, ?)
  `).run(telegram_id.toString(), tagId, username || null, full_name, referralCode);

  return db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
}

function generateTagIdInternal() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const digits = '0123456789';
  const stmt = db.prepare('SELECT 1 FROM users WHERE tag_id = ?');
  let tag;
  do {
    const c1 = chars[Math.floor(Math.random() * 26)];
    const c2 = chars[Math.floor(Math.random() * 26)];
    const d1 = digits[Math.floor(Math.random() * 10)];
    const d2 = digits[Math.floor(Math.random() * 10)];
    const d3 = digits[Math.floor(Math.random() * 10)];
    tag = `#${c1}${c2}${d1}${d2}${d3}`;
  } while (stmt.get(tag));
  return tag;
}

export function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}

export function setSetting(key, value) {
  db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(key, value);
}

export function logUserAction(userId, action, detail) {
  try {
    db.prepare('INSERT INTO user_logs (user_id, action, detail) VALUES (?, ?, ?)')
      .run(userId, action, detail || null);
  } catch (err) {
    console.error('[DB] logUserAction error:', err);
  }
}

export function addNotification(userId, message) {
  try {
    db.prepare('INSERT INTO notifications (user_id, message) VALUES (?, ?)')
      .run(userId, message);
  } catch (err) {
    console.error('[DB] addNotification error:', err);
  }
}

export function getUnreadNotifications(userId) {
  try {
    const rows = db.prepare('SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at ASC')
      .all(userId);
    db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0').run(userId);
    return rows;
  } catch (err) {
    console.error('[DB] getUnreadNotifications error:', err);
    return [];
  }
}

export function getUserByTagId(tagId) {
  return db.prepare('SELECT * FROM users WHERE tag_id = ?').get(tagId);
}

export function getUserByTelegramId(telegramId) {
  return db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(telegramId.toString());
}

export function getInvoiceByCode(code) {
  return db.prepare('SELECT * FROM invoices WHERE invoice_code = ?').get(code);
}

export function getOrderByRef(ref) {
  return db.prepare('SELECT * FROM orders WHERE order_ref = ?').get(ref);
}

export function getUserOrders(userId, statusFilter) {
  if (statusFilter && statusFilter.length > 0) {
    const placeholders = statusFilter.map(() => '?').join(',');
    return db.prepare(`SELECT * FROM orders WHERE user_id = ? AND status IN (${placeholders}) ORDER BY created_at DESC`)
      .all(userId, ...statusFilter);
  }
  return db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').all(userId);
}

export function getUserInvoices(userId) {
  return db.prepare('SELECT * FROM invoices WHERE user_id = ? ORDER BY created_at DESC').all(userId);
}

export function getUserTransactions(userId) {
  return db.prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC').all(userId);
}

export function getPendingInvoices() {
  return db.prepare(`
    SELECT i.*, u.tag_id, u.username, u.telegram_id, u.full_name
    FROM invoices i
    JOIN users u ON i.user_id = u.id
    WHERE i.status IN ('pending', 'waiting_approval')
    ORDER BY i.created_at ASC
  `).all();
}

export function getAllUsers(limit = 100) {
  return db.prepare('SELECT * FROM users ORDER BY created_at DESC LIMIT ?').all(limit);
}

export function searchUsers(query) {
  const q = `%${query}%`;
  return db.prepare(`
    SELECT * FROM users 
    WHERE tag_id LIKE ? OR username LIKE ? OR telegram_id LIKE ? OR full_name LIKE ?
    ORDER BY created_at DESC LIMIT 50
  `).all(q, q, q, q);
}

export function getStats() {
  const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  const totalBalance = db.prepare('SELECT COALESCE(SUM(balance), 0) as sum FROM users').get().sum;
  const totalDeposited = db.prepare('SELECT COALESCE(SUM(total_deposit), 0) as sum FROM users').get().sum;
  const totalOrders = db.prepare('SELECT COUNT(*) as count FROM orders').get().count;

  const depositStatus = db.prepare(`
    SELECT status, COUNT(*) as count FROM invoices GROUP BY status
  `).all();

  const orderStatus = db.prepare(`
    SELECT status, COUNT(*) as count FROM orders GROUP BY status
  `).all();

  const revenue = db.prepare(`
    SELECT COALESCE(SUM(amount), 0) as sum FROM transactions WHERE type = 'deposit' AND reference IN (
      SELECT invoice_code FROM invoices WHERE status = 'approved'
    )
  `).get().sum;

  return { totalUsers, totalBalance, totalDeposited, totalOrders, depositStatus, orderStatus, revenue };
}

export function getReferralCount(userId) {
  return db.prepare('SELECT COUNT(*) as count FROM users WHERE referred_by = ?').get(userId).count;
}

export function getReferrals(userId) {
  return db.prepare('SELECT tag_id, username, full_name, created_at FROM users WHERE referred_by = ? ORDER BY created_at DESC').all(userId);
}

// ── Atomic Transactions ──

export const approveDeposit = db.transaction((invoiceId, adminId) => {
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(invoiceId);
  if (!invoice) throw new Error('Invoice tidak ditemukan');
  if (invoice.status === 'approved') throw new Error('Invoice sudah di-approve sebelumnya');
  if (invoice.status === 'rejected') throw new Error('Invoice sudah di-reject');
  if (invoice.status === 'cancelled') throw new Error('Invoice sudah dibatalkan');
  if (invoice.status === 'expired') throw new Error('Invoice sudah expired');

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(invoice.user_id);
  if (!user) throw new Error('User tidak ditemukan');

  const balanceBefore = user.balance;
  const balanceAfter = balanceBefore + invoice.amount;

  // Credit user balance
  db.prepare('UPDATE users SET balance = ?, total_deposit = total_deposit + ? WHERE id = ?')
    .run(balanceAfter, invoice.amount, invoice.user_id);

  // Update invoice status
  db.prepare("UPDATE invoices SET status = 'approved' WHERE id = ?").run(invoiceId);

  // Log transaction
  db.prepare(`
    INSERT INTO transactions (user_id, type, reference, amount, balance_before, balance_after)
    VALUES (?, 'deposit', ?, ?, ?, ?)
  `).run(invoice.user_id, invoice.invoice_code, invoice.amount, balanceBefore, balanceAfter);

  // Log admin action
  db.prepare(`
    INSERT INTO admin_actions (admin_id, action, target_user_id, detail)
    VALUES (?, 'approve_deposit', ?, ?)
  `).run(adminId, invoice.user_id, `Approved invoice ${invoice.invoice_code} (+${invoice.amount})`);

  return { invoice, user, balanceBefore, balanceAfter };
});

export const rejectDeposit = db.transaction((invoiceId, adminId, reason) => {
  const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(invoiceId);
  if (!invoice) throw new Error('Invoice tidak ditemukan');
  if (invoice.status === 'approved') throw new Error('Invoice sudah di-approve, tidak bisa di-reject');
  if (invoice.status === 'rejected') throw new Error('Invoice sudah di-reject sebelumnya');

  db.prepare("UPDATE invoices SET status = 'rejected' WHERE id = ?").run(invoiceId);

  db.prepare(`
    INSERT INTO admin_actions (admin_id, action, target_user_id, detail)
    VALUES (?, 'reject_deposit', ?, ?)
  `).run(adminId, invoice.user_id, `Rejected invoice ${invoice.invoice_code}. Reason: ${reason || 'No reason'}`);

  return { invoice };
});

export const adjustBalance = db.transaction((userId, amount, adminId, reason) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!user) throw new Error('User tidak ditemukan');

  const balanceBefore = user.balance;
  const balanceAfter = balanceBefore + amount;

  if (balanceAfter < 0) throw new Error('Saldo tidak boleh negatif');

  db.prepare('UPDATE users SET balance = ? WHERE id = ?').run(balanceAfter, userId);

  const type = amount >= 0 ? 'adjustment' : 'adjustment';
  db.prepare(`
    INSERT INTO transactions (user_id, type, reference, amount, balance_before, balance_after)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(userId, type, `ADMIN:${adminId}`, amount, balanceBefore, balanceAfter);

  db.prepare(`
    INSERT INTO admin_actions (admin_id, action, target_user_id, detail)
    VALUES (?, 'adjust_balance', ?, ?)
  `).run(adminId, userId, `${amount >= 0 ? 'Add' : 'Deduct'} ${Math.abs(amount)}. Reason: ${reason}`);

  return { user, balanceBefore, balanceAfter };
});

export const cancelOrder = db.transaction((orderId, userId) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (!order) throw new Error('Order tidak ditemukan');
  if (order.user_id !== userId) throw new Error('Anda tidak memiliki order ini');
  if (!['active', 'processing', 'waiting'].includes(order.status)) {
    throw new Error('Order tidak bisa dibatalkan');
  }

  db.prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?").run(orderId);

  // Refund if needed
  if (order.price && order.price > 0) {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    const balanceBefore = user.balance;
    const balanceAfter = balanceBefore + order.price;
    db.prepare('UPDATE users SET balance = ? WHERE id = ?').run(balanceAfter, userId);
    db.prepare(`
      INSERT INTO transactions (user_id, type, reference, amount, balance_before, balance_after)
      VALUES (?, 'cancel', ?, ?, ?, ?)
    `).run(userId, order.order_ref, order.price, balanceBefore, balanceAfter);
  }

  db.prepare(`
    INSERT INTO user_logs (user_id, action, detail)
    VALUES (?, 'cancel_order', ?)
  `).run(userId, `Cancelled order ${order.order_ref}`);

  return { order };
});

export const createInvoice = db.transaction((userId, amount, uniqueCode, total, invoiceCode, expiresAt) => {
  db.prepare(`
    INSERT INTO invoices (invoice_code, user_id, amount, unique_code, total, expires_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(invoiceCode, userId, amount, uniqueCode, total, expiresAt);

  return db.prepare('SELECT * FROM invoices WHERE invoice_code = ?').get(invoiceCode);
});

export const createOrder = db.transaction((userId, orderRef, provider, service, country, phone, price, expiresAt) => {
  db.prepare(`
    INSERT INTO orders (order_ref, user_id, provider, service, country, phone, price, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(orderRef, userId, provider, service, country, phone, price, expiresAt);

  db.prepare('UPDATE users SET total_orders = total_orders + 1 WHERE id = ?').run(userId);

  return db.prepare('SELECT * FROM orders WHERE order_ref = ?').get(orderRef);
});

// ── Backup ──

export async function backupDatabase(destinationPath) {
  return new Promise((resolve, reject) => {
    try {
      const backup = db.backup(destinationPath);
      function step() {
        try {
          const remaining = backup.step(100);
          if (backup.remaining > 0 || remaining > 0) {
            setImmediate(step);
          } else {
            backup.finish();
            resolve();
          }
        } catch (err) {
          try { backup.finish(); } catch (_) {}
          reject(err);
        }
      }
      step();
    } catch (err) {
      reject(err);
    }
  });
}

console.log(`[DB] Connected: ${dbPath}`);
