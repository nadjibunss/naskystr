module.exports = {
  apps: [
    {
      name: 'nasky-user-bot',
      script: './src/userBot.js',
      cwd: '.',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      autorestart: true,
      restart_delay: 3000,
      out_file: './logs/user-bot.log',
      error_file: './logs/user-bot-error.log',
      env_file: '.env',
      max_memory_restart: '512M'
    },
    {
      name: 'nasky-backup-bot',
      script: './src/backupBot.js',
      cwd: '.',
      autorestart: true,
      restart_delay: 5000,
      out_file: './logs/backup-bot.log',
      error_file: './logs/backup-bot-error.log',
      env_file: '.env',
      max_memory_restart: '256M'
    },
    {
      name: 'nasky-admin-bot',
      script: './src/adminBot.js',
      cwd: '.',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      autorestart: true,
      restart_delay: 3000,
      out_file: './logs/admin-bot.log',
      error_file: './logs/admin-bot-error.log',
      env_file: '.env',
      max_memory_restart: '512M'
    }
  ]
};
