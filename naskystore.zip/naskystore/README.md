# NASKY STORE

Sistem bot Telegram multi-proses untuk layanan OTP Store dengan panel admin, backup otomatis, dan pembayaran QRIS manual.

## Prerequisites

- Node.js 22+
- PM2 (`npm install -g pm2`)
- SQLite3 (included via better-sqlite3)

## Installation

```bash
# 1. Extract zip
cd /root
unzip naskystore.zip -d nasky-store
cd nasky-store

# 2. Install dependencies
npm run install-deps

# 3. Setup environment
cp .env.example .env
nano .env  # Edit semua konfigurasi
```

## Configuration Guide (.env)

| Variable | Description |
|----------|-------------|
| `BOT_USER_TOKEN` | Token bot Telegram untuk user |
| `BOT_ADMIN_TOKEN` | Token bot Telegram untuk admin (berbeda dari user) |
| `BACKUP_BOT_TOKEN` | Token bot Telegram untuk backup |
| `ADMIN_IDS` | ID Telegram admin, pisahkan koma |
| `BACKUP_CHAT_ID` | Chat ID untuk kirim file backup |
| `DB_PATH` | Path file SQLite (default: /root/nasky-data/nasky.sqlite) |
| `BACKUP_DIR` | Direktori backup (default: /root/nasky-data/backups) |
| `BACKUP_INTERVAL_MS` | Interval backup otomatis (ms) |
| `MAX_BACKUPS` | Maksimum file backup yang disimpan |
| `PORT` | Port Express webhook watcher |
| `WATCHER_SECRET` | Secret key untuk webhook payment |
| `QRIS_TTL_SECONDS` | Masa berlaku invoice QRIS (default: 180) |
| `DEFAULT_QRIS_STATIC` | String QRIS static (diisi via admin panel) |
| `OTP_PROVIDER_ENABLED` | `true` jika provider OTP sudah dikonfigurasi |

## Database Backup Before Update

**WAJIB** backup DB sebelum update apapun:
```bash
cp /root/nasky-data/nasky.sqlite /root/nasky-data/nasky-backup-pre-update.sqlite
```

## PM2 Commands

```bash
# Start all processes
pm2 start ecosystem.config.cjs

# Save PM2 config
pm2 save

# View logs
pm2 logs nasky-user-bot
pm2 logs nasky-admin-bot
pm2 logs nasky-backup-bot

# Restart
pm2 restart all

# Stop
pm2 stop all
```

## DB Restore Procedure

1. Stop all bots: `pm2 stop all`
2. Backup current DB: `cp nasky.sqlite nasky.sqlite.bak`
3. Copy backup file: `cp nasky-backup-YYYY-MM-DD_HH-mm-ss.sqlite nasky.sqlite`
4. Restart: `pm2 restart all`

## Test Checklist

- [ ] `npm install` berhasil tanpa error
- [ ] `npm run check` lolos untuk semua file
- [ ] `/start` user bot membuat user baru dengan tag ID unik
- [ ] Top up generate invoice dengan kode unik 3 digit
- [ ] QRIS image generate dari static string
- [ ] Invoice expired tidak bisa di-approve
- [ ] Double-approval deposit diblok (idempotency)
- [ ] Cancel order hanya bisa oleh pemilik
- [ ] Admin approve/reject dengan atomic transaction
- [ ] Backup otomatis jalan dan rotate file lama
- [ ] Webhook payment update status ke waiting_approval
- [ ] Leaderboard auto-refresh setiap 5 menit

## 🚧 Soon / Coming Soon Features

1. **OTP Provider Integration**
   - API call ke provider OTP belum diimplementasikan karena spesifikasi endpoint bervariasi per provider
   - Scaffold order creation sudah lengkap (DB, status tracking, cancel, refund)
   - Aktifkan dengan `OTP_PROVIDER_ENABLED=true` dan isi `OTP_PROVIDER_URL` + `OTP_PROVIDER_KEY`

2. **Auto-Payment Watcher**
   - Webhook `/webhook/payment` sudah tersedia untuk menerima notifikasi payment
   - Perlu integrasi dengan payment gateway/bank API untuk trigger otomatis
   - Saat ini deposit bersifat MANUAL dan memerlukan approval admin

## Project Structure

```
naskystore/
├── src/
│   ├── userBot.js          # Bot user-facing
│   ├── adminBot.js         # Panel admin + Express watcher
│   ├── backupBot.js        # Backup otomatis & manual
│   ├── database.js         # Schema & migrations
│   ├── watcher.js          # Express webhook payment
│   └── utils/
│       ├── helpers.js      # Utility functions
│       ├── qris.js         # QRIS image generator
│       └── leaderboard.js  # Leaderboard cache
├── logs/                   # Log files
├── package.json
├── ecosystem.config.cjs
├── .env.example
└── README.md
```

## License

MIT
