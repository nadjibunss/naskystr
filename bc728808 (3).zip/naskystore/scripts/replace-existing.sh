#!/usr/bin/env bash
set -euo pipefail
TARGET=/root/naskkkk/nasky-store-deployable
SRC=/root/naskkkk/naskystore
[ -d "$TARGET" ] || { echo "Target tidak ditemukan: $TARGET"; exit 1; }
[ -f "$TARGET/.env" ] && cp "$TARGET/.env" /root/nasky-data/naskystore.env.backup || true
cp -a "$TARGET/src" "/root/nasky-data/src-before-naskystore-$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
cp -r "$SRC/src/"* "$TARGET/src/"
cp -r "$SRC/backup-bot" "$TARGET/"
cp "$SRC/ecosystem.config.cjs" "$TARGET/"
cd "$TARGET"
pm install
node --check src/index.js
node --check src/bots/user.js
node --check src/bots/admin.js
node --check backup-bot/index.js
pm2 delete nasky-store 2>/dev/null || true
pm2 delete nasky-database-backup 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save
