#!/usr/bin/env bash
set -euo pipefail
APP=/root/naskkkk/naskystore
mkdir -p /root/nasky-data/backups
cd "$APP"
[ -f .env ] || cp .env.example .env
npm install
node --check src/index.js
node --check src/bots/user.js
node --check src/bots/admin.js
node --check backup-bot/index.js
pm2 start ecosystem.config.cjs
pm2 save
