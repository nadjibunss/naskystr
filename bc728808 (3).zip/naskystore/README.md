# NASKY STORE FULL — naskystore.zip

This package implements the requested balance, top-up, top-up history, profile totals, active orders, transaction history, unique order references, professional admin reply keyboard, leaderboard refresh, QRIS invoice flow, and database backup bot. Unready features are explicitly marked Soon instead of silently doing nothing.

It uses Telegram ReplyKeyboardMarkup custom keyboards, not inline keyboards. Telegram custom keyboards send the selected button text as a normal message to the bot. [web:59][web:55][web:240]

The backup bot uses `await db.backup()` and uploads the completed SQLite file as a local stream to `sendDocument`, avoiding invalid empty HTTP URL errors. [web:118][web:111]

Install in a new directory:
```bash
mkdir -p /root/naskkkk/naskystore
unzip -o naskystore.zip -d /root/naskkkk/naskystore
cd /root/naskkkk/naskystore
cp .env.example .env
nano .env
npm install
pm2 start ecosystem.config.cjs
pm2 save
```

Use the included `.env.example`. Replace all placeholder token values and preserve the existing DB_PATH if migrating data.
